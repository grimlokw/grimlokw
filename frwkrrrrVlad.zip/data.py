import pandas as pd
from troida_data_service import TroidaDataService

def data(ticket, interval, start_date, end_date):
    service = TroidaDataService()
    file = service.f(ticket, interval, start_date, end_date)
    df = pd.read_csv(file, sep=";")
    df["<DATE>"] = pd.to_datetime(df["<DATE>"].astype(str), format="%y%m%d")
    df["<TIME>"] = df["<TIME>"].astype(str).str.zfill(6)
    df["<TIME>"] = pd.to_datetime(df["<TIME>"], format="%H%M%S").dt.time
    df["datetime"] = pd.to_datetime(df["<DATE>"].astype(str) + " " + df["<TIME>"].astype(str))
    df = df.rename(columns={
        "<OPEN>": "open",
        "<HIGH>": "high",
        "<LOW>": "low",
        "<CLOSE>": "close",
        "<VOL>": "volume"
    })
    df = df[["datetime", "open", "high", "low", "close", "volume"]]
    return df