import backtrader as bt
import pandas as pd
import ccxt
import time


class SmaCross(bt.Strategy):
    params = (('fast_sma_period', 5), ('slow_sma_period', 30),)

    def __init__(self):
        self.sma1 = bt.indicators.SMA(self.datas[0], period=self.params.fast_sma_period)
        self.sma2 = bt.indicators.SMA(self.datas[0], period=self.params.slow_sma_period)
        self.crossover = bt.indicators.CrossOver(self.sma1, self.sma2)
        self.buy_price = None

# --------------
    def log(self, txt, dt=None):
        dt = dt or self.datas[0].datetime.datetime(0)
        dt_str = dt.strftime('%d.%m.%y %H:%M:%S')
        print(f'{dt_str} {txt}')

    def next(self):
        if self.crossover > 0:
            self.log('BUY SIGNAL')
            self.buy(size=self.calculate_trade_size())
        elif self.crossover < 0:
            self.log('SELL SIGNAL')
            if self.position.size > 0:
                self.close()

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            self.log(f'ORDER {order.Status[order.status]}')
            return
        if order.status in [order.Completed]:
            if order.isbuy():
                self.buy_price = order.executed.price
                position_value_usd = order.executed.size * order.executed.price
                self.log(f'BUY EXECUTED, Price: {self.buy_price:.2f}, Position Value: {position_value_usd:.2f} USD')
            elif order.issell():
                sell_price = order.executed.price
                position_value_usd = order.executed.size * sell_price
                self.log(f'SELL EXECUTED, Price: {sell_price:.2f}, Position Value: {position_value_usd:.2f} USD')
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log(f'ORDER {order.Status[order.status]}')

    def calculate_trade_size(self):
        cash = self.broker.get_cash()
        size = (cash * 1.00) / self.data.close[0]
        return size

# -------------------
def get_kucoin_data(symbol, timeframe, since=None, limit=5000):
    kucoin = ccxt.kucoin()
    all_data = []
    while True:
        ohlcv = kucoin.fetch_ohlcv(symbol, timeframe, since=since, limit=limit)
        if not ohlcv:
            break
        data = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        all_data.append(data)
        since = ohlcv[-1][0] + 1
        time.sleep(5)
    all_data = pd.concat(all_data)
    all_data['datetime'] = pd.to_datetime(all_data['timestamp'], unit='ms')
    all_data.set_index('datetime', inplace=True)
    return all_data

# -------------------
if __name__ == '__main__':
    cerebro = bt.Cerebro()
    cerebro.addstrategy(SmaCross)

    data = bt.feeds.PandasData(dataname=get_kucoin_data('ETH/USDT', '5m'))

    cerebro.adddata(data)
    cerebro.broker.setcash(1000.0)
    cerebro.broker.setcommission(commission=0.0)

    starting_value = cerebro.broker.getvalue()
    cerebro.run()
    final_value = cerebro.broker.getvalue()

    print('Starting Portfolio Value: %.2f' % starting_value)
    print('Final Portfolio Value: %.2f' % final_value)

    initial_price = data.close.array[0]
    final_price = data.close.array[-1]
    profit_percent = ((final_value - starting_value) / starting_value) * 100
    print('Percent of Profit: %.2f%%' % profit_percent)

    buy_and_hold_profit_percent = ((final_price - initial_price) / initial_price) * 100
    print('Percent of Profit for Bought and Hold: %.2f%%' % buy_and_hold_profit_percent)

    cerebro.plot(volume=False)
