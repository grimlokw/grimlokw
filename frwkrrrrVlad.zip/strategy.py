import backtrader as bt
import datetime
from data import data

data_params = ["SBER", "1h", "250101", "250303"]

class Strategy(bt.Strategy):
    def log(self, txt, dt=None):
        dt = dt or self.datas[0].datetime.date(0)
        print('%s, %s' % (dt.isoformat(), txt))

    def __init__(self):
        self.dataclose = self.datas[0].close
        self.order = None

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return

        if order.status in [order.Completed]:
            if order.isbuy():
                self.log('BUY EXECUTED, %.2f' % order.executed.price)
            elif order.issell():
                self.log('SELL EXECUTED, %.2f' % order.executed.price)

        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')

        self.order = None

# Сама стратегия
    def next(self):
        current_date = self.datas[0].datetime.date(0)
        if current_date.day != 1:
            return
        one_month_ago = current_date - datetime.timedelta(days=30)
        past_prices = [self.dataclose[i] for i in range(-len(self.dataclose), 0)
                       if self.datas[0].datetime.date(i) <= one_month_ago]

        if not past_prices:
            return

        past_price = past_prices[-1]
        if self.dataclose[0] >= (past_price * 1.05):
            self.log('BUY CREATE, %.2f' % self.dataclose[0])
            self.order = self.buy()
        elif self.dataclose[0] <= (past_price * 0.95):
            self.log('SELL CREATE, %.2f' % self.dataclose[0])
            self.order = self.sell()


if __name__ == '__main__':
    cerebro = bt.Cerebro()
    df = data(*data_params)
    cerebro.addstrategy(Strategy)
    data = bt.feeds.PandasData(dataname=df, datetime='datetime', open='open', high='high', low='low', close='close', volume='volume')
    cerebro.adddata(data)
    cerebro.addanalyzer(bt.analyzers.Transactions, _name='transactions') # добавление анализатора для сохранения журнала
    cerebro.broker.setcash(1000)
    start_value = cerebro.broker.getvalue()
    print('\nStarting Portfolio Value: %.2f' % cerebro.broker.getvalue())
    results = cerebro.run()
    cerebro.plot()
    print('Final Portfolio Value: %.2f' % cerebro.broker.getvalue())
    print('Percent of profit: %.2f' % (((cerebro.broker.getvalue() - start_value) / start_value) * 100), '%')
    transactions = results[0].analyzers.transactions.get_analysis()  # журнал ордеров через предоставленную в bt функцию
