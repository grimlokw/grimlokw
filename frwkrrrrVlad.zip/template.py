import backtrader as bt
from data import data

start_cash = 1000
data_params = "параметры запрашиваемых данных('AAPL', '15m' и тд)"


class Strategy(bt.Strategy):
    def log(self, txt, dt=None):
        dt = dt or self.datas[0].datetime.date(0)
        print('%s, %s' % (dt.isoformat(), txt))

    def __init__(self):
        # код стратегии

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return

        if order.status in [order.Completed]:
            if order.isbuy():
                self.log('BUY EXECUTED, %.2f' % order.executed.price)
            elif order.issell():
                self.log('SELL EXECUTED, %.2f' % order.executed.price)
        self.order = None

    def next(self):
        # код стратегии


if __name__ == '__main__':
    cerebro = bt.Cerebro()
    cerebro.adddata(data(data_params)) # функция которая возвращает данные по нужным нам параметрам
    cerebro.addanalyzer(bt.analyzers.Transactions, _name='transactions')  # добавление анализатора для сохранения журнала
    cerebro.broker.setcash(start_cash)
    start_value = cerebro.broker.getvalue()

    results = cerebro.run()

    prnt_results() # функция которая будет выводить результаты
    graph() # функция которая будет рисовать нужный график


    transactions = results[0].analyzers.transactions.get_analysis()  # журнал ордеров через предоставленную в bt функцию

