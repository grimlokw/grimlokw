import aiohttp
from pandas.tseries.offsets import Tick
import requests
import finnhub
import random
import json
from io import StringIO
import asyncio
import yfinance as yf
import pandas as pd
from datetime import datetime,timedelta
from dateutil import parser
# import nasdaqdatalink
async def main():
        ##MOEX ISS - Moscow Stock Exchange
        ##print(requests.get('https://iss.moex.com/iss/securities.json?q=AAPL').json())   
        ##EqYAV7YsELTC9REFCvGZ Quandl Nasdaq for trade, bunds
        ##Hell docs and doesn`t working:
        ##nasdaqdatalink.read_key(filename="/data/.corporatenasdaqdatalinkapikey")
        ##data = nasdaqdatalink.get_table('WIKI/PRICES', qopts = { 'columns': ['ticker', 'date', 'close'] }, ticker = ['AAPL', 'MSFT'], date = { 'gte': '2016-01-01', 'lte': '2016-12-31' })
        ##print(data)     
        TroidaDataService().invoke_tests()
        pass
class TroidaDataService:
    def __init__(self):
        pass
    def invoke_tests(self):
        print(self.get_stocks(limit=10))
        print(self.get_crypto(limit=10))
        print(self.f('AAPL','5min','2023-03-03','2025-03-21 14:30'))

    def filter_by_date_range_v2(self,values, start_time, end_time):
        filtered_values = []
        start_time=parser.parse(start_time)
        end_time=parser.parse(end_time)
        for val in values:
            current_datetime = parser.parse(val["datetime"])
            if start_time <= current_datetime <= end_time:
                filtered_values.append(val)
        return filtered_values

    def filter_by_date_range(self,data, start_date, end_date):
        filtered_data = {}
        start_date = parser.parse(start_date)
        end_date = parser.parse(end_date)
        for timestamp, values in data.items():
            current_date = parser.parse(timestamp)
            if start_date <= current_date <= end_date:
                filtered_data[timestamp] = values
        return filtered_data       
    def f(self,symbol,interval,start_date,end_date):
        try:
            finnhub_client = finnhub.Client(api_key="cveoqbpr01qjugsdvprgcveoqbpr01qjugsdvps0")
            js1 = json.loads(json.dumps(finnhub_client.quote(symbol),indent=4))
            df = pd.DataFrame(columns=["datetime", "open", "high", "low", "close", "volume"])
            new_row1 = {
            "datetime": end_date,
            "open": js1["o"],
            "high": js1["h"],
            "low": js1["l"],
            "close": js1["c"],
            "volume": "NaN"
            }
            df = pd.concat([df, pd.DataFrame([new_row1])], ignore_index=True)
        except:
            pass
        try:
            d = requests.get(f'https://api.twelvedata.com/time_series?show_plan=true&symbol={symbol}&interval={interval}&apikey=b7a66b072f21453780d4166017e3931d')
            js2 = json.loads(d.content)
            vals2=self.filter_by_date_range_v2(js2['values'], start_date, end_date)
            for el in vals2:
                new_row2 = {
                "datetime": el["datetime"],
                "open": el["open"],
                "high": el["high"],
                "low": el["low"],
                "close": el["close"],
                "volume": el["volume"]
                }
                df = pd.concat([df, pd.DataFrame([new_row2])], ignore_index=True)
        except:
            pass
        try:
            polygonio = requests.get(f"https://api.polygon.io/v1/open-close/{symbol}/{end_date[:10]}?adjusted=true&apiKey=2aHQvq8gYab0S_77PA1IqgVkaH3RWV_C")
            js3 = json.loads(polygonio.content)
            new_row3 = {
            "datetime": end_date,
            "open": js3["open"],
            "high": js3["high"],
            "low": js3["low"],
            "close": js3["close"],
            "volume": js3["volume"]
            }
            df = pd.concat([df, pd.DataFrame([new_row3])], ignore_index=True)
        except:#need update plan to get data from any date
            pass
        try:
            aapl = yf.Ticker(symbol)  
            new_row4 = {
            "datetime": str(datetime.now()),
            "open": aapl.info["open"],
            "high": aapl.info["targetHighPrice"],
            "low": aapl.info["targetLowPrice"],
            "close": "NaN",
            "volume": aapl.info["volume"]
            }
            df = pd.concat([df, pd.DataFrame([new_row4])], ignore_index=True)
        except:
            pass
        try:
            url = f'https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={symbol}&interval={interval}&apikey=E5CV4H7QPSNDAVD6&adjusted=true&extended_hours=true&outputsize=full&datatype=json'
            r = requests.get(url)
            js5 = json.loads(r.content)
            filtered = self.filter_by_date_range(js5[f'Time Series ({interval})'],start_date,end_date)
            for timestamp, values in filtered.items():
                new_row5 = {
                "datetime": timestamp,
                "open": values["1. open"],
                "high": values["2. high"],
                "low": values["3. low"],
                "close": values["4. close"],
                "volume": values["5. volume"]
                }
                df = pd.concat([df, pd.DataFrame([new_row5])], ignore_index=True)
        except:
            pass
        rand = random.randint(1, 99999999)
        df.to_csv(f'out_found{rand}.csv',index=False)
        return f'out_found{rand}.csv'
    def get_stocks(self,limit=-1):
        #very long time function, recieves all stocks data
        url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
        tables = pd.read_html(url)
        tickers = None
        if limit != -1:
            tickers = tables[0]["Symbol"].tolist()[:limit]
        else:
            tickers = tables[0]["Symbol"].tolist()
        df = pd.DataFrame(columns=["datetime", "open", "high", "low", "close", "volume"])
        for ticker in tickers:
                tickerObj = yf.Ticker(ticker)
                new_row4 = {
                "datetime": str(datetime.now()),
                "open": tickerObj.info["open"],
                "high": tickerObj.info["targetHighPrice"],
                "low": tickerObj.info["targetLowPrice"],
                "close": "NaN",
                "volume": tickerObj.info["volume"]
                }
                df = pd.concat([df, pd.DataFrame([new_row4])], ignore_index=True)
                finnhub_client = finnhub.Client(api_key="cveoqbpr01qjugsdvprgcveoqbpr01qjugsdvps0")
                js1 = json.loads(json.dumps(finnhub_client.quote(ticker),indent=4))
                df = pd.DataFrame(columns=["datetime", "open", "high", "low", "close", "volume"])
                new_row1 = {
                "datetime": "NaN",
                "open": js1["o"],
                "high": js1["h"],
                "low": js1["l"],
                "close": js1["c"],
                "volume": "NaN"
                }
                df = pd.concat([df, pd.DataFrame([new_row1])], ignore_index=True)
                try:
                    d = requests.get(f'https://api.twelvedata.com/time_series?show_plan=true&symbol={ticker}&interval=5min&apikey=b7a66b072f21453780d4166017e3931d')
                    js2 = json.loads(d.content)
                    for el in js2['values']:
                        new_row2 = {
                        "datetime": el["datetime"],
                        "open": el["open"],
                        "high": el["high"],
                        "low": el["low"],
                        "close": el["close"],
                        "volume": el["volume"]
                        }
                        df = pd.concat([df, pd.DataFrame([new_row2])], ignore_index=True)
                except:
                    pass
                try:
                    polygonio = requests.get(f"https://api.polygon.io/v1/open-close/{ticker}/{str(datetime.now()-timedelta(days=1))[:10]}?adjusted=true&apiKey=2aHQvq8gYab0S_77PA1IqgVkaH3RWV_C")
                    js3 = json.loads(polygonio.content)
                    new_row3 = {
                    "datetime": "NaN",
                    "open": js3["open"],
                    "high": js3["high"],
                    "low": js3["low"],
                    "close": js3["close"],
                    "volume": js3["volume"]
                    }
                    df = pd.concat([df, pd.DataFrame([new_row3])], ignore_index=True)
                except:
                    pass
                try:
                    url = f'https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={ticker}&interval=5min&apikey=E5CV4H7QPSNDAVD6&adjusted=true&extended_hours=true&outputsize=full&datatype=json'
                    r = requests.get(url)
                    js5 = json.loads(r.content)
                    for timestamp, values in js5['Time Series (5min)'].items():
                        new_row5 = {
                        "datetime": timestamp,
                        "open": values["1. open"],
                        "high": values["2. high"],
                        "low": values["3. low"],
                        "close": values["4. close"],
                        "volume": values["5. volume"]
                        }
                        df = pd.concat([df, pd.DataFrame([new_row5])], ignore_index=True)
                except:
                    pass
        rand = random.randint(1, 99999999)
        df.to_csv(f'out_stocks{rand}.csv',index=False)
        return f'out_stocks{rand}.csv'
    def get_crypto(self,limit=-1):
        #very long time function, recieves all cryptocoins data
        url = "https://api.coingecko.com/api/v3/coins/list?x_cg_demo_api_key=CG-3hMnepXvMbrEasdHnGAJ4y8o"
        headers = {"accept": "application/json"}
        response = requests.get(url, headers=headers)
        js = json.loads(response.content)
        df = pd.DataFrame(columns=["crypto","price"])
        iter = 0
        for coin in js:
             if iter != -1 and iter > limit:
                break
             uri = f"https://api.coingecko.com/api/v3/simple/price?ids={coin['id']}&vs_currencies=usd&x_cg_demo_api_key=CG-3hMnepXvMbrEasdHnGAJ4y8o"
             res = requests.get(uri)
             print(df)
             print("\n")
             if res.status_code==200:
                 js1 = json.loads(res.content)         
                 new_row = {
                 "crypto":coin["id"],
                 "price":js1[str(coin['id'])].get('usd',"NaN")
                 }
                 df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
             else:
                new_row = {
                "crypto":coin["id"],
                "price":"NaN"
                }
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
             iter = iter + 1
        rand = random.randint(1, 99999999)
        df.to_csv(f'out_crypto{rand}.csv',index=False)
        return f'out_crypto{rand}.csv'
if __name__ == "__main__":
    asyncio.run(main())